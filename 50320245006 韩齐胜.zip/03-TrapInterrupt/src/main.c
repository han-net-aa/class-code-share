#include "print.h"
#include "trap.h"

extern void test_illegal_instruction(void);

void main(void) {
    print_string("RISC-V Bootloader\n");
    print_string("Hello XOS!\n");
    
    printf("Initializing interrupt handler...\n");
    init_interrupt();
    
    printf("Testing illegal instruction exception...\n");
    test_illegal_instruction();
    
    printf("Test completed!\n");
    
    while (1) {
        // 无限循环
    }
}
