#include "sbi.h"
#include "types.h"

void console_putchar(int c) {
    // 直接写入 UART 寄存器
    volatile char *uart = (volatile char *)0x10000000;
    uart[0] = c;
}

int console_getchar() {
    // 简单返回，实际应该从 UART 读取
    return 0;
}

void shutdown() {
    // 空实现
    while(1);
}
