#include "defs.h"
#include "trap.h"

extern void trap_vector();

void print_hex(uint64 val) {
    char hex[] = "0123456789abcdef";
    print_string("0x");
    for (int i = 60; i >= 0; i -= 4) {
        char c = hex[(val >> i) & 0xF];
        if (c != '0' || i == 0) {
            print_char(c);
        }
    }
}

void kernel_trap_init()
{
    print_string("[TRACE] trap_vector = ");
    print_hex((uint64)trap_vector);
    print_string("\n");
    
    w_mtvec((uint64)trap_vector);
    uint64 mtvec_val = r_mtvec();
    print_string("[TRACE] mtvec = ");
    print_hex(mtvec_val);
    print_string("\n");
    
    w_mstatus(r_mstatus() | MSTATUS_MIE);
    print_string("[TRACE] interrupts enabled (MIE)\n");
}

void init_interrupt() {
    kernel_trap_init();
}

void print_trapframe(struct trapframe *tf) {
    print_string("trapframe at ");
    print_hex((uint64)tf);
    print_string("\n");
    print_regs(&tf->gpr);
}

void print_csr(struct trapframe *tf) {
    print_string("  status   ");
    print_hex(tf->status);
    print_string("\n  epc      ");
    print_hex(tf->epc);
    print_string("\n  stval    ");
    print_hex(tf->stval);
    print_string("\n  cause    ");
    print_hex(tf->cause);
    print_string("\n");
}

void print_regs(struct pushregs *gpr) {
    print_string("  zero     "); print_hex(gpr->zero); print_string("\n");
    print_string("  ra       "); print_hex(gpr->ra); print_string("\n");
    print_string("  sp       "); print_hex(gpr->sp); print_string("\n");
    print_string("  gp       "); print_hex(gpr->gp); print_string("\n");
    print_string("  tp       "); print_hex(gpr->tp); print_string("\n");
    print_string("  t0       "); print_hex(gpr->t0); print_string("\n");
    print_string("  t1       "); print_hex(gpr->t1); print_string("\n");
    print_string("  t2       "); print_hex(gpr->t2); print_string("\n");
    print_string("  s0       "); print_hex(gpr->s0); print_string("\n");
    print_string("  s1       "); print_hex(gpr->s1); print_string("\n");
    print_string("  a0       "); print_hex(gpr->a0); print_string("\n");
    print_string("  a1       "); print_hex(gpr->a1); print_string("\n");
    print_string("  a2       "); print_hex(gpr->a2); print_string("\n");
    print_string("  a3       "); print_hex(gpr->a3); print_string("\n");
    print_string("  a4       "); print_hex(gpr->a4); print_string("\n");
    print_string("  a5       "); print_hex(gpr->a5); print_string("\n");
    print_string("  a6       "); print_hex(gpr->a6); print_string("\n");
    print_string("  a7       "); print_hex(gpr->a7); print_string("\n");
    print_string("  s2       "); print_hex(gpr->s2); print_string("\n");
    print_string("  s3       "); print_hex(gpr->s3); print_string("\n");
    print_string("  s4       "); print_hex(gpr->s4); print_string("\n");
    print_string("  s5       "); print_hex(gpr->s5); print_string("\n");
    print_string("  s6       "); print_hex(gpr->s6); print_string("\n");
    print_string("  s7       "); print_hex(gpr->s7); print_string("\n");
    print_string("  s8       "); print_hex(gpr->s8); print_string("\n");
    print_string("  s9       "); print_hex(gpr->s9); print_string("\n");
    print_string("  s10      "); print_hex(gpr->s10); print_string("\n");
    print_string("  s11      "); print_hex(gpr->s11); print_string("\n");
    print_string("  t3       "); print_hex(gpr->t3); print_string("\n");
    print_string("  t4       "); print_hex(gpr->t4); print_string("\n");
    print_string("  t5       "); print_hex(gpr->t5); print_string("\n");
    print_string("  t6       "); print_hex(gpr->t6); print_string("\n");
}

void handle_interrupt(struct trapframe *tf) {
    uint64 cause_code = tf->cause & 0xFF;
    print_string("Interrupt! Code = ");
    print_hex(cause_code);
    print_string("\n");
}

void handle_illegal_instruction(struct trapframe *tf) {
    print_string("\n========== ILLEGAL INSTRUCTION EXCEPTION ==========\n");
    print_string("An illegal instruction was executed!\n");
    print_string("Exception address (EPC): ");
    print_hex(tf->epc);
    print_string("\n");
    
    uint32 *inst_addr = (uint32 *)tf->epc;
    uint32 inst = *inst_addr;
    print_string("Instruction causing exception: 0x");
    for (int i = 28; i >= 0; i -= 4) {
        char c = "0123456789abcdef"[(inst >> i) & 0xF];
        print_char(c);
    }
    print_string("\n");
    
    print_string("Handling illegal instruction...\n");
    tf->epc = tf->epc + 4;
    print_string("Skipping illegal instruction, continuing at ");
    print_hex(tf->epc);
    print_string("\n");
    print_string("==================================================\n\n");
}

void handle_exception(struct trapframe *tf) {
    uint64 cause_code = tf->cause & 0xFF;
    
    print_string("[EXCEPTION] Cause: ");
    print_hex(cause_code);
    print_string(" ");
    
    if (cause_code == 2) {
        print_string("(Illegal Instruction)\n");
        handle_illegal_instruction(tf);
    } else {
        print_string("(Unknown exception)\n");
        print_csr(tf);
        while(1);
    }
}

void trap(struct trapframe *tf) {
    print_string("[TRAP] trap() called, cause=");
    print_hex(tf->cause);
    print_string("\n");
    
    if (tf->cause & (1ULL << 63)) {
        handle_interrupt(tf);
    } else {
        handle_exception(tf);
    }
}
